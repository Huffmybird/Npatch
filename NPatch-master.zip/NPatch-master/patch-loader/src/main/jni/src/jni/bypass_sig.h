#pragma once

#include <jni.h>

namespace lspd {

    void RegisterBypass(JNIEnv* env);

} // namespace lspd
